jQuery(document).ready(function($) {
    $('.bvi-panel-open').bvi('Init',bvi);
});